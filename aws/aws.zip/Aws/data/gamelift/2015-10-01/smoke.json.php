<?php
// This file was auto-generated from sdk-root/src/data/gamelift/2015-10-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListBuilds', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribePlayerSessions', 'input' => [ 'PlayerSessionId' => 'psess-fakeSessionId', ], 'errorExpectedFromService' => true, ], ],];
